============================================================
  Bitcoin Wallet Risk Analyzer - Instructions
============================================================

WHAT IS THIS?
  A standalone tool that classifies Bitcoin wallets as
  BENIGN or CRIMINAL using a Graph Neural Network (GATv2).

REQUIREMENTS:
  - Python 3.10+ (https://www.python.org/downloads/)
  - Internet connection (fetches live data from mempool.space)

------------------------------------------------------------
  HOW TO USE
------------------------------------------------------------

OPTION 1: One-click setup script (recommended)

  Windows:
    Double-click setup_and_run.bat
    First run creates a virtual environment and installs
    dependencies automatically. Subsequent runs skip setup.

  macOS / Linux:
    chmod +x setup_and_run.sh
    ./setup_and_run.sh

  You can also pass an address directly:
    setup_and_run.bat 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa
    ./setup_and_run.sh 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa

OPTION 2: Run manually (if you already have dependencies)

    python wallet_analyzer.py <BITCOIN_ADDRESS>

  Example:
    python wallet_analyzer.py 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa

------------------------------------------------------------
  OPTIONS
------------------------------------------------------------

  --save-charts     Save charts (risk gauge, feature
                    importance, transaction volume)
  --open-charts     Save and automatically open charts
  --model PATH      Use a custom model file (.pt)
  --output-dir DIR  Save charts to a specific folder

  Examples:
    python wallet_analyzer.py 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa
    python wallet_analyzer.py --save-charts bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh
    python wallet_analyzer.py --open-charts 3FZbgi29cpjq2GjdwV8eyHuJJnkLtktZc5

------------------------------------------------------------
  OUTPUT
------------------------------------------------------------

  The tool displays:
    - Classification: BENIGN or CRIMINAL
    - Risk Score: 0-100% (LOW / MODERATE / HIGH / CRITICAL)
    - Confidence: how certain the model is
    - Wallet balance and transaction totals
    - Top features that influenced the classification

  Charts (only with --save-charts or --open-charts):
    Saved to analyses/<address>/ folder:
    - risk_gauge.png          Semi-circle risk meter
    - feature_importance.png  Bar chart of feature weights
    - tx_volume.png           Weekly incoming/outgoing volume

------------------------------------------------------------
  IMPORTANT NOTES
------------------------------------------------------------

  - First run downloads the GNN model from GitHub Releases
    and installs dependencies (may take a few minutes).
  - Analysis time depends on how many transactions the
    wallet has (typically 5-30 seconds).
  - The tool needs internet access to fetch blockchain data.
  - After each analysis you can enter another address
    or type 'q' to quit.

------------------------------------------------------------
  TROUBLESHOOTING
------------------------------------------------------------

  "No transactions found"
    The address has no confirmed transactions or may be
    invalid. Check the address and try again.

  "No internet connection"
    The tool requires internet to reach mempool.space.
    Check your connection and firewall settings.

  "Model file not found"
    The GNN model is auto-downloaded on first run. Make
    sure you have internet access. You can also manually
    place gnn_model.pt in an outputs/ folder next to
    the script.

  Setup script fails
    Make sure Python 3.10+ is installed and in your PATH.
    On Windows, check "Add Python to PATH" during install.

============================================================
